/*
SQLyog Job Agent v11.33 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.5.16-log : Database - transcript
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`transcript` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `transcript`;

/*View structure for view detailed_enrollments */

/*!50001 DROP TABLE IF EXISTS `detailed_enrollments` */;
/*!50001 DROP VIEW IF EXISTS `detailed_enrollments` */;

/*!50001 CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `detailed_enrollments` AS select `e`.`enrollment_id` AS `enrollment_id`,`e`.`student_id` AS `student_id`,`e`.`academic_year` AS `academic_year`,`e`.`program_id` AS `program_id`,`e`.`level_id` AS `level_id`,`l`.`level_name` AS `level_name`,`s`.`student_name` AS `student_name`,`s`.`matricule` AS `matricule`,`sp`.`program_name` AS `program_name` from (((`enrollments` `e` left join `levels` `l` on((`l`.`level_id` = `e`.`level_id`))) left join `students` `s` on((`e`.`student_id` = `s`.`student_id`))) left join `school_programs` `sp` on((`e`.`program_id` = `sp`.`program_id`))) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
