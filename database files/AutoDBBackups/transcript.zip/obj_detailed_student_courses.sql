/*
SQLyog Job Agent v11.33 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.5.16-log : Database - transcript
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`transcript` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `transcript`;

/*View structure for view detailed_student_courses */

/*!50001 DROP TABLE IF EXISTS `detailed_student_courses` */;
/*!50001 DROP VIEW IF EXISTS `detailed_student_courses` */;

/*!50001 CREATE ALGORITHM=TEMPTABLE DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `detailed_student_courses` AS select `sc`.`student_course_id` AS `student_course_id`,`sc`.`enrollment_id` AS `enrollment_id`,`sc`.`course_id` AS `course_id`,`sc`.`ca_mark` AS `ca_mark`,`sc`.`exam_mark` AS `exam_mark`,`sc`.`teacher_id` AS `teacher_id`,`sc`.`semester` AS `semester`,`sc`.`credit_value` AS `credit_value`,`e`.`academic_year` AS `academic_year`,`e`.`level_id` AS `level_id`,`e`.`level_name` AS `level_name`,`s`.`student_id` AS `student_id`,`s`.`student_name` AS `student_name`,`s`.`matricule` AS `matricule`,`c`.`course_code` AS `course_code`,`c`.`course_name` AS `course_name`,`p`.`person_name` AS `person_name` from (((((`student_courses` `sc` left join `detailed_enrollments` `e` on((`e`.`enrollment_id` = `sc`.`enrollment_id`))) left join `students` `s` on((`s`.`student_id` = `e`.`student_id`))) left join `courses` `c` on((`c`.`course_id` = `sc`.`course_id`))) left join `program_courses` `pc` on(((`pc`.`course_id` = `sc`.`course_id`) and (`pc`.`level_id` = `e`.`level_id`) and `pc`.`program_id`))) left join `personel` `p` on((`p`.`person_id` = `sc`.`teacher_id`))) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
