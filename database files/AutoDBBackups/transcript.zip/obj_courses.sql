/*
SQLyog Job Agent v11.33 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.5.16-log : Database - transcript
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`transcript` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `transcript`;

/*Table structure for table `courses` */

DROP TABLE IF EXISTS `courses`;

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_name` varchar(50) CHARACTER SET latin1 NOT NULL,
  `course_code` varchar(10) CHARACTER SET latin1 NOT NULL,
  `credit_value` int(11) NOT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

/*Data for the table `courses` */

insert  into `courses`(`course_id`,`course_name`,`course_code`,`credit_value`) values (1,'Data Security','SE408',4),(2,'System Design','SE301',3),(3,'Introduction to Microbiology','MLS301',4),(4,'Entrepreneurship','COT307',2),(5,'Sports and Physical Education','SPT100',2),(6,'CHEMISTRY OF ORGANIC COMPOUNDS','UKE 384',2),(7,'MATHEMATICAL METHODS III','FAT 532',3),(8,'CHEMICAL KINETICS','SGT 337',4),(9,'QUANTUM CHEMISTRY','XVQ 699',6),(10,'Functional French 2','CBI 760',3),(11,'Functional French 1','BHG 504',2),(12,'Mobile Application Development','IMQ 854',4),(13,'Law and Government','BLC 835',2),(14,'Programming 1','CUY 559',5),(15,'Programming 2','OQB 873',2),(16,'Calculus 1','UEP 392',2),(17,'Calculus 2','LXU 341',3),(18,'Civics and Ethics','YSK 038',2),(19,'Mathematical Methods of Physics','XRB 732',5);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
