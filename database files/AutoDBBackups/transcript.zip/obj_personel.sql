/*
SQLyog Job Agent v11.33 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.5.16-log : Database - transcript
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`transcript` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `transcript`;

/*Table structure for table `personel` */

DROP TABLE IF EXISTS `personel`;

CREATE TABLE `personel` (
  `person_id` int(11) NOT NULL AUTO_INCREMENT,
  `person_name` varchar(50) CHARACTER SET latin1 NOT NULL,
  `qualification` varchar(100) CHARACTER SET latin1 DEFAULT NULL,
  PRIMARY KEY (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

/*Data for the table `personel` */

insert  into `personel`(`person_id`,`person_name`,`qualification`) values (1,'Garland Myrick','IV'),(2,'Angeline Watson','Ed.D.'),(3,'Howard Hostetler','Eng.D.'),(4,'Rossana Funderburk','V'),(5,'Orlando Choi','B.Sc.'),(6,'Alphonse Arevalo','D.C.'),(7,'Quentin Brent','Jr.'),(8,'Serita Carmichael','Pharm.D.'),(9,'Sherman Buckner','L.L.B.'),(10,'Neta Mackie','B.F.A.'),(11,'Sondra Paterson','B.S.'),(12,'Misty Clements','I'),(13,'Nicholas Jeter','M.D.'),(14,'Chadwick Edge','M.B.A.'),(15,'Marx Ruby','D.O.'),(16,'Joleen Bratton','A.B.'),(17,'Ellis Comstock','III'),(18,'Louie Conover','Sr.'),(19,'Franklyn Kee','B.E.'),(20,'Corazon Zielinski','LL.M.'),(21,'Carmelo Linder','M.F.A.'),(22,'Barbar Ridley','II'),(23,'Fredrick Feldman','D.Phil.'),(24,'Saturnina Cahill','VII'),(25,'Maple Peltier','B.A.'),(26,'Christin Mattos','Ph.D.'),(27,'Stewart Burchett','J.D.'),(28,'Sharmaine Cisneros','M.Eng'),(29,'Robin Hindman','LL.D.'),(30,'Randy Denton','M.S.'),(31,'Ann Graham','M.A.'),(32,'Niki Rosario','M.Sc.'),(33,'Gino Barlow','VI'),(34,'Kacie Stacey','M.L.A.'),(35,'Marjorie Gruber','B.Tech.'),(36,'Cory Muller','VIII'),(37,'Thomasine Healy',NULL);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
