/*
SQLyog Job Agent v11.33 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.5.16-log : Database - transcript
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`transcript` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `transcript`;

/*View structure for view detailed_program_courses */

/*!50001 DROP TABLE IF EXISTS `detailed_program_courses` */;
/*!50001 DROP VIEW IF EXISTS `detailed_program_courses` */;

/*!50001 CREATE ALGORITHM=TEMPTABLE DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `detailed_program_courses` AS select `pc`.`program_course_id` AS `program_course_id`,`pc`.`program_id` AS `program_id`,`pc`.`course_id` AS `course_id`,`pc`.`credit_value` AS `credit_value`,`pc`.`level_id` AS `level_id`,`pc`.`semester` AS `semester`,`sp`.`program_name` AS `program_name`,`sp`.`school_id` AS `school_id`,`c`.`course_name` AS `course_name`,`c`.`course_code` AS `course_code` from ((`program_courses` `pc` left join `school_programs` `sp` on((`sp`.`program_id` = `pc`.`program_id`))) left join `courses` `c` on((`pc`.`course_id` = `c`.`course_id`))) */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
