/*
SQLyog Job Agent v11.33 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.5.16-log : Database - transcript
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`transcript` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `transcript`;

/*Table structure for table `school_programs` */

DROP TABLE IF EXISTS `school_programs`;

CREATE TABLE `school_programs` (
  `program_id` int(11) NOT NULL AUTO_INCREMENT,
  `program_name` varchar(100) CHARACTER SET latin1 NOT NULL,
  `school_id` int(11) NOT NULL,
  PRIMARY KEY (`program_id`),
  KEY `school_id` (`school_id`),
  CONSTRAINT `school_programs_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

/*Data for the table `school_programs` */

insert  into `school_programs`(`program_id`,`program_name`,`school_id`) values (1,'Sales',5),(2,'Research and Development',5),(3,'Research and Development',1),(4,'Operations',3),(5,'Research and Development',5),(6,'Consulting',5),(7,'Human Resources',2),(8,'Information Technology',5),(9,'Finance',4),(10,'Sales',4),(11,'Operations',1),(12,'Consulting',1),(13,'Information Technology',3),(14,'Operations',1),(15,'Sales',1),(16,'Consulting',1),(17,'Executive',1),(18,'Finance',2),(19,'Sales',5);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
